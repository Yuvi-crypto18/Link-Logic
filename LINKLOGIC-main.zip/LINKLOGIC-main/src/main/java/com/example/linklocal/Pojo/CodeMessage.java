package com.example.linklocal.Pojo;

public class CodeMessage {
       String code;
       String lang;
       String input;
       public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getLang() {
        return lang;
    }
    public void setLang(String lang) {
        this.lang = lang;
    }
    public String getInput() {
        return input;
    }
    public void setInput(String input) {
        this.input = input;
    }


}
