package com.example.linklocal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinklocalApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinklocalApplication.class, args);
	}

}
